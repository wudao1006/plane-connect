# Brief Status Report

**{{project_name}}** | {{date}} | {{total_tasks}} tasks

## Quick Overview
- ✅ **Completed:** {{completed_tasks}}
- 🔄 **In Progress:** {{in_progress_tasks}}
- ⏳ **Pending:** {{pending_tasks}}
- 📊 **Progress:** {{completion_rate}}

## Active Tasks
{{in_progress_tasks}}

## Next Up
{{pending_tasks}}

## Completed Today
{{done_tasks}}

---
*Quick snapshot for rapid status assessment*